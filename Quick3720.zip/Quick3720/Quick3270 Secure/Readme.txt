README.TXT - Quick3270 Secure


1) Introduction
2) Contact
3) Install options
4) SSL
5) EHLLAPI
6) Additional options
7) Program history



1) Introduction
   ============
Quick3270 is a powerful, high reliable 3270/5250 terminal emulator for Windows 95/98/NT/2000/XP. Quick3270 is fast, use low memory and includes a large number of advanced features:
- 3270 Connectivity: Microsoft Host Integration Server (FMI3270) and TN3270
- 5250 Connectivity: TN5250
- GUI-on-the-fly
- Cut/Copy/Paste Data
- IND$FILE file transfer (Structured Field and Buffered)
- Transfer of list of files
- Graphic terminal emulation support (GDDM,...)
- 3287 Printer emulation (LU1 and LU3)
- OLE Automation Server
- Macro language
- Standard and enhanced EHLLAPI support
- Large number of host code pages
- English, French, German, Italian and Spanish user interfaces
- English, French and German help files
- SNMP support
- and many more...
Site license and the complete C/C++ source code are available.

Please contact me if you want to report bugs, grammar mistakes, or
give your opinion about the program, or any comments etc...



2) Contact
   =======
DN-Computing
7, rue du Foss�
67150 Erstein - France
Tel: +33 (0) 388 980 311 
Fax: +33 (0) 388 982 120

e-mail : info@dn-computing.com
WWW    : http://www.dn-computing.com

EU VAT number: FR35424175123




3) Install options
   ===============

Quick3270 setup supports currently two command line options: 
/Silent (no user prompt)
/noshortcut (no shortcut created on desktop)




4) SSL
   ===============

SSL (Secure Sockets Layer) allows you to establish a secure connection between the emulator and a host computer. 

Quick3270 uses the OpenSSL library to implement SSL-based security. Two dll's are located in the product installation directory for this reason. They are called ssleay32.dll and libeay32.dll

The cryptography tool kit implementing the Secure Sockets Layer (SSL v2/v3) and Transport Layer Security (TLS v1) network protocols and related cryptography standards.

SSL support includes software developed by the OpenSSL project for the OpenSSL toolkit. This feature includes cryptographic software written by Eric Young. This feature includes software written by Tim Hudson.




5) EHLLAPI
   ===============
Quick3270 High Level Language API provides compatibility with IBM's
Standard and Enhanced EHLLAPI.
The Standard EHLLAPI DLL file name is EHLAPI32.DLL.
The Enhanced EHLLAPI DLL file name is PCSHLL32.DLL.
The Personal Communications Session API DLL file name PCSAPI32.DLL

The files are designed for Windows 32 bits application only.

Note: Quick3270 setup program don't add the Quick3270 program path to the PATH environment variable. 

Summary of available EHLLAPI functions (Ask us if you need not yet available functions):
 1 - CONNECTPS
 2 - DISCONNECTPS
 3 - SENDKEY
 4 - WAIT
 5 - COPYPS
 6 - SEARCHPS
 7 - QUERYCURSORLOC
 8 - COPYPSTOSTR
 9 - SETSESSIONPARAMETERS
10 - QUERYSESSIONS
11 - RESERVE
12 - RELEASE
13 - COPYOIA
14 - QUERYFIELDATTRIBUTE 
15 - COPYSTRTOPS
18 - PAUSE                           
20 - QUERYSYSTEM
21 - RESETSYSTEM
22 - QUERYSESSIONSTATUS
23 - STARTHOSTNOTIFICATION
24 - QUERYHOSTUPDATE
25 - STOPHOSTNOTIFICATION
30 - SEARCHFIELD
31 - FINDFIELDPOSITION
32 - FINDFIELDLENGTH
33 - COPYSTRINGTOFIELD
34 - COPYFIELDTOSTRING
40 - SETCURSOR
41 - STARTCLOSEINTERCEPT
42 - QUERYCLOSEINTERCEPT
43 - STOPCLOSEINTERCEPT
50 - STARTKSINTERCEPT
51 - GETKEY
52 - POSTINTERCEPTSTATUS
53 - STOPKSINTERCEPT
60 - LOCKPSAPI
61 - LOCKWINDOWSERVICESAPI

90 - SENDFILE
91 - RECEIVEFILE
99 - CONVERT

101 - CONNECTWINDOWSERVICES
102 - DISCONNECTWINDOWSERVICES
103 - QUERYWINDOWCOORDINATES
104 - WINDOWSTATUS
105 - CHANGEPSNAME
106 - CHANGEWINDOWNAME
 
List of supported options you can set with SETSESSIONPARAMETERS:
STRLEN/STREOT, EOT=c, ESC=c, AUTORESET/NORESET, TWAIT/LWAIT/NWAIT,
NOATTRB/ATTRB, EAB/NOEAB, XLATE/NOXLATE, DISPLAY/NODISPLAY,STRLEN/STREOT, EOT=c,
SRCHALL/SRCHFROM, SRCHFRWD/SRCHBKWD, NOCFGSIZE/CFGSIZE, OLDOIA/NEWOIA,
FPAUSE/IPAUSE 



How to use the EHLAPI32.DLL from a C file
----

#include "QHLLAPI.h"

HINSTANCE hHllapi_DLL;
WORD wFunction;
WORD wRetCode;

hHllapi_DLL = LoadLibrary("C:\\Program Files\\Quick3270\\EHLAPI32.dll");
hllapi = (LPFNDLL_hllapi) GetProcAddress(hHllapi_DLL, "hllapi");

wFunction = 21;   // Reset
hllapi(&wFunction, NULL, NULL, &wRetCode);
switch (wRetCode) {
   case RC_INVALID_PS:
      // 1  HLLAPI not Loaded
      break;
   case RC_SYSTEM_ERROR:  
      break;
}

...

----



6) Additional options
   ==================
Options you can add to the configuration file or registry
to hide some menu options. This options will even be removed
from the toolbar.
Note: All file paths can contain environment-variable strings

[Menu]
HideMenuBar=True
HideNew=True
HideOpen=True
HideOpenSame=True
HideOpenNew=True
HideSave=True
HideSaveAs=True
HideSaveAsDefault=True
HideOpenLayout=True
HideSaveLayout=True
HideRecentFileList=True

HideGUI=True                  (Hides the View / Quick GUI menu option)
HideTrace=True                (Hides the Session / Start trace menu option)
HideExit=True
HideExitAll=True

HideSettings=True
HideSessionCfg=True
HideFileTransfer=True

HideMacro=True
HideMacroEdit=True
HideMacroRecord=True

HideKeybordMap=True

DeviceNameReadOnly=True       (User can't change TN3270 device name)
ConfigurationReadOnly=True    (user can't overwrite configuration file)
UseOldKbdMap=True             (Use the old keyboard mapping tool - used before version 3.60)


[General]                     (note: path are expanded. You can include environment-variable strings "%variableName%")
szDefaultDirectory=<path>     (if specified, this path will be used for macro, trace and configuration files)
SchemeDirectory=<path>        (if specified, this path will be used for color, keypad, keyboard and GUI scheme files)

NoPrompt=True                 (No error message prompt)
KeepAliveTimer=milliseconds   (Keep alive timer interval for Telnet connections)
Keyboard122=True              (enable support of 122 keys keyboards - ask us for details)
UseSystemCaret=True           (uses the Windows system caret - used for specific input devices)

[Logging]
LogHLLAPI=True                (Log HLLAPI Calls)
LogPath=<path>                (if not specified the default path is used)

[HLLAPI]
SendKeyWait=False             (Used for HLLAPI interface compatibility with other emulators)
MemoryDump=True               (Enable a memory dump of HLLAPI calls. Used to store the last 100 HLLAPI calls)


Alarm option: Sound alarm if a given character is at the given
screen location.
(sample: Sound alarm every second if the character "U" is at location 1,1)
[Alarm] 
AlarmOn=True
Row=1
Line=1
Timer=1000
Token=U



7) Program history
   ===============
August 2006 - 3.83
     - Added: Cut/Copy/Paste uses now by default Unicode characters.
     - Added: Batch file transfer can import IBM PComm Send Receive List files (.SRL)
     - Added: The delete key deletes now the characters of the marked area if any
     - Added: Option to bypass Windows GDI for print screen.

June 2006 - 3.82
     - Added: Undo paste option
     - Added: Macro recorder uses now attribute and cursor location for synchronization
     - Added: New macro functions: Date$, Time$ and GetAttrib
     - Added: GDDM supports now bitmaps display 
     - Added: Telnet Timing Mark option
     - Added: 5250 emulation supports more "advanced" functionalities.
     - Added: New Path option added to the setup program: Q3270.exe /path "c:\my application".
     - Added: Quick3270 Thai edition display now a second "Thai" cursor if compose mode is enabled.

July 2005 - 3.75
     - New: Bitstream Vera Mono font added to the Quick3270 package
     - New: Possibility to scroll the screen in GUI mode.
     - New: drag & drop color scheme file into Quick3270 window to apply the color scheme.
     - New: drag & drop macro file into Quick3270 window to execute the macro.
     - Fixed: "Save as default session..." Proxy setting overwrites the connection parameters.
     - Fixed: Right mouse button doesn't display the edit popup menu if the menu bar is hidden.

May 2005 - 3.73
     - Added: New hotspot options. Hotspot can now be displayed in text mode (reverse color)
     - Improved support for LU1 formatting commands (Quick3287 printer emulator)
     - Fixed: Macro - WaitForKbdUnlock returns before keyboard is unlocked
     - Fixed: Printscreen to file cannot create a file when append option is selected
     - Fixed: The SysReq function works now as expected with a TN3270E connection

March 2005 - 3.72
     - Added: pcsQuerySessionList function (PCSAPI32.DLL)
     - Changed: The default path for Macro files is now the program path
     - Fixed: Automation - GetString appends an useless NULL character to string result.

December 2004 - 3.71
     - Fixed: Keyboard locked after AltGr or Ctrl+Alt (bug of version 3.70).
     - Fixed: IND$FILE File transfer don't work with VTAM/TUBES environment.
     - Macro: Encrypted passwords can only be written in hidden fields

October 2004 - 3.70
    - Added: pcsStartSession and pcsStopSession (PCSAPI32.DLL)
    - Added: Read configuration file is now faster and the file is opened in read-only mode
    - Added: Added option to disable the keyboard auto-repeat feature for 3270/5250 function keys
    - Fixed: Wrong display attributes returned by CopyPS and CopyPStoString (EHLLAPI)

July 2004 - 3.69
    - Added: Option to send Printscreen to file
    - Added: If there is a marked area, only the marked area will be printed
    - Added: Hidden field input will now be recorded encrypted (Macro).

May 2004 - 3.68
    - Added: Option to insert Tabs as field separator (Copy/Cut)
    - Added: Graphic display now supports the Set Character Angle order
    - Fixed: Wrong result returned by EHLLAPI QuerySessions
    - Fixed: Wrong default keyboard map on German/Swiss keyboards
    - Fixed: Wrong default keyboard map on Dutch/Belgium keyboards

March 2004 - 3.66
    - Added: Print screen supports now screens with graphic display
    - Added: Keyboard accelerators for menu options
    - Added: String comparison (>, =, <, <=, >=, <> - macro language)
    - Added: Improved EEHLAPI compatibility with IBM PComm
    - Added: Possibility to choose the cell size for graphic display
    - Fixed: Caps lock key don't work as expected on non French and German keyboards

December 2003 - 3.65
    - Added: Enhanced EHLLAPI support
    - Added: Spanish and Italian user interface
    - Added: Backup hosts for TN3270 and TN5250 connectivity

August 03 - 3.60
    - Added: Graphical keyboard mapping dialog box
    - Added: Possibility to start macros from the keypad
    - Added: File I/O functions to macro language
    - Added: 3270 Cursor Select function
    - Added: 5250 Host Print function
    - Added: keyboard auto-unlock option 
    - Fixed: EHLLAPI Dll was not unloaded properly

March 03 - 3.55
    - Added: Support for Automation objects (macro language)
    - Added: Integration of TextPipe Pro, a powerful text manipulation and extraction software
    - Added: Option for B&W print screen

Jan 03 - v.3.50
    - Added: Auto-GUI option
    - Added: New options for Copy/Paste
    - Added: New install program. Includes now a "silent" install option

June 02 - v3.30
    - Added: 3812 Printer emulation support (TN5250)
    - Added: Device name negociation (TN5250)
    - Added: Image support for graphic emulation
    - New: Quick3270 Thai Edition available from Fujitsu Thailand

Jan 02 - v3.22
    - Added: Customizable window title
    - Added: Auto-reconnect option (Telnet)
    - Added: "Run the same" and "Run other..." menu option
    - Added: Option to to popup keypad on right mouse clic  
    - Fixed: "Destructive Backspace" option don't work in 5250 mode
    - Fixed: Some function key bug on 5250 emulation

Nov 01 - v3.21
    - Added: Left Ctrl key can be mapped
    - Improved Bitmap font resizing

Nov 01 - v3.20
    - Added: EHLLAPI interface
    - Added: SNMP support
    - Added: Customizable toolbar
    - Added: Message line for 5250 emulation
    - Added: Transfer list of files
    - Added: Auto-start macro
    - Added: Record macro option
    - Added: Graphic screens are resizable

July 01 - v3.17
    - Added: Thai Host Code Page
    - Added: Lines per Inch option for 3287 emulation
    - Improved support for graphic emulation (3179G)
    - Fixed: TN5250 negotiation problem on some server
    - Fixed: Bug when several sessions are started with the layout file
    - Fixed: Several bugs with the macro language
    - Fixed: A Bracket error with SNA Server connection (FMI)

Feb 01 - v3.10
    - Added: Script language
    - Added: Support of layout file (to save several sessions, display and printer, in one file) 
    - Added: New keys: Next Word, Previous Word
    - Added: COM IPersistFile support
    - Added: LU name is now displayed on the status bar (3270)
    - Added: Settings can now be save in the registry 
    - Fixed: Several file transfer bugs with IND$FILE in CUT mode
    - Fixed: An Automation deadlock is removed

Oct 00 - v3.07
    - Added: Printer page settings are now backed up in the configuration files (Quick3270 and Quick3287)
    - Fixed: Quick3287 printing problem due to the new "ByPass GDI" code (doesn't print if "ByPass GDI" option is not selected)

Oct 00 - v3.06
    - Added: Purchase online menu option
    - Added: Code pages for Euro currency symbol
    - Added: Quick3287 LU1 transparency support

Oct 00 - v3.05
    - Added: Recent file list
    - Added: Quick3270 configuration files area now associated with the application
    - Added: Menu bar can now be hidden
    - Changed: User settings are now stored under the HKEY_CURRENT_USER key
    - Fixed: Input focus problem after a click on a keypad button
    - Fixed: The Keypad can no more be maximized

Sept 00 - v3.04
    - Added: Row oriented paste data option (Scott Burch)
    - Added: Telnet Keep-Alive option (Richard C. Luna)
    - Fixed: OLE Automation incompatibility with new protection system (Juan Carlos Daza)
    - Fixed: "Open session" and "Open Session new" incompatibility with new protection system

Sept 00 - v3.03
    - Added: End Of Field key (Ctrl-End)
    - Fixed: File transfer, wrong conversion of the "Y" character 
             when receiving text files (Tom Hansen)
    - Fixed: Blinking attribute was ignored under some conditions
    - Fixed: Graphic draw line was one pixel too short

August 00 - v3.02
    - Fixed: Connection problem on some TN3270E server
    - Fixed: Keypad window may have a bad size

July 00 - v3.00
    - Added: 5250 terminal emulation
    - Added: Context help
    - Added: Lightpen support
    - Changed: New software protection system

May 00 - v2.69
    - Fixed: Printer Emulator unable to connect in TN3270E mode

May 00 - v2.68
    - Added: Append option when sending file to host
    - Added: Print timestamp header on print screen
    - Added: Possibility to start the program from a WEB page URL like tn3270://hostname [port]
    - Fixed: Read Buffer bug - program may crash under some circumstances
    - Fixed: Display bug on progress bar for large file transfer  
    - Fixed: File transfer dialog box update bug.
             Settings were not properly updated when a file transfer scheme file was selected

February 00 - v2.60
    - Added: Host graphic support (GDDM,...)
    - Added: 3287 host print
    - Added: Improved NVT/ANSI emulation
    - Added: OLE functions for IND$FILE file transfer
    - Added: DUP and Fieldmark keys

October 99 - v2.50
    - Added: Code Page support for File transfer
    - Added: Page setup and printer font selection
    - Added: French and German user interface and help file
    - Shortcut for the cent character (Alt+c)


September 99 - v2.27
    - Fixed: Program could crash when using IND$FILE file transfer with TN3270 connectivity


September 99 - v2.26
    - Fixed: Bad ANSI to EBCDIC translation for some language specific characters


June 99 - v2.25
    - Fixed: Accept now uppercase characters on Numeric Fields
    - Fixed: Correct the GetString Automation Error when a negative length is given
    - Automation: The software starts in invisible mode now


June 99 - v2.24
    - Fixed: Program crash when rigth control key is pressed


May 99 - v2.23
    - Added: OLE MoveTo, MoveRelative, Row and Col function calls are buffered
             if type ahead is enable to avoid synchronization problems
    - Fixed: Attn key now flushes the type ahead buffer
    - Fixed: Unable to disable the type ahead buffer
             

May 99 - v2.22
    - Added: Display an error message if the SNA Server DLL is not found
    - Fixed: Display bug with NVT data's (TN3270E connection)
    - Fixed: Type ahead bug with TN3270 connection
    - Fixed: Focus problem on the select font Dialog box
    - Fixed: Bad Cursor placement for BackTab and Home Keystrokes
    - Fixed: Pf19 and Pf20 were inverted
    - Fixed: Printer LUs are listed in the screen Session Settings Dialog box
    - Fixed: File transfer bug with TN3270 connection
    - Fixed: Bug on Visible OLE property


April 99 - v2.21
    - Faster screen update


April 99 - v2.20
    - Added: Customizable colors and keyboard remapping
    - Added: Type ahead buffer
    - Added: 3270 function Keys (Fast Left, Fast right, Erase Input)
    - Fixed: Connection problem with some TN3270E Server


March 99 - v2.10
    - Added: Support for IND$FILE file transfer (CMS, TSO and CICS)
    - Improved 3270 data parser
    - Added: Install/Uninstall program
    - Added: 3270 function keys (Attention and SysReq)


January 99 - v2.02
    - Added: TN3270E support
    - Fixed: Bug with SNA Server connection under Windows NT


December 98 - v2.01
    - Added: Support of blinking attribute
    - Fixed: Display bug on color attributes
    - Fixed: Bug on OLE Wait... functions


December 98 - v2.0
    - Added: TN3270 connectivity
    - Added: OLE Automation Server feature
    - Added: Trace file (read and write)
    - Added: Toolbar


April 98 - v1.0
    - First release of Quick3270.
    - Includes the basic features of a 3270 emulator.
    - Connects to MS SNA Server using the FMI API.
    - Support most of the extended attributes .
    - Partial support of Graphic Escape characters
    - Support of Cut/Copy/Paste data
