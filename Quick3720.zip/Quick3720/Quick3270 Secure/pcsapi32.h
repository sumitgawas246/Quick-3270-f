/****************************************************************************/
/*                                                                          */
/*   PCSAPI32.H                                                             */
/*                                                                          */
/*   Definitions for the Quick3270 PCSAPI32 specification                   */
/*                                                                          */
/****************************************************************************/

/*--------------------------------------------------------------------------*/
/*  Definition for Query Emulator Status                                    */
/*--------------------------------------------------------------------------*/

#define PCS_SESSION_STARTED          0x00000001
#define PCS_SESSION_ONLINE           0x00000002
#define PCS_SESSION_API_ENABLED      0x00000004
#define PCS_SESSION_INTERIM_STATE    0x00000008

/*--------------------------------------------------------------------------*/
/*  Definition for Start Session                                            */
/*--------------------------------------------------------------------------*/

#define PCS_HIDE                     0
#define PCS_SHOW                     1
#define PCS_MINIMIZE                 2
#define PCS_MAXIMIZE                 3

#define PCS_SUCCESSFUL               0
#define PCS_INVALID_ID               1
#define PCS_USED_ID                  2
#define PCS_INVALID_PROFILE          3
#define PCS_SYSTEM_ERROR             9


/*--------------------------------------------------------------------------*/
/*  Definition for Stop Session                                             */
/*--------------------------------------------------------------------------*/

#define PCS_SAVE_AS_PROFILE          0
#define PCS_SAVE_ON_EXIT             1
#define PCS_NOSAVE_ON_EXIT           2

/*--------------------------------------------------------------------------*/
/*  Definition for Query Session List                                       */
/*--------------------------------------------------------------------------*/

typedef union tag_SESSNAME {     // Name field of SessInfo structure
  char ShortName;                // Short session ID (A-Z)
  ULONG Handle;                  // Session handle
  } SESSNAME;

typedef struct tag_SESSINFO {    // Description of a single session
  SESSNAME Name;                 // Session name (ID or handle)
  ULONG    Status;               // Session status (PCS_SESSION_* bit flags)
  } SESSINFO;


/*--------------------------------------------------------------------------*/
/* Api Function Prototypes                                                  */
/*--------------------------------------------------------------------------*/

extern ULONG WINAPI pcsQueryEmulatorStatus(char cShortSessionID);
extern ULONG WINAPI pcsStartSession(LPSTR lpProfile, char cShortSessionID, USHORT fuCmdShow);
extern BOOL  WINAPI pcsStopSession(char cShortSessionID, USHORT fuSaveProfile);
extern ULONG WINAPI pcsQuerySessionList(ULONG Count, SESSINFO *SessList);


/*--------------------------------------------------------------------------*/
/*  Ordinal numbers for function entry points                               */
/*--------------------------------------------------------------------------*/

#define ord_pcsQueryEmulatorStatus     3
#define ord_pcsStartSession            5
#define ord_pcsStopSession             6
#define ord_pcsQuerySessionList        9
