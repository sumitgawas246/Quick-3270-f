/******************************************************************************/
/*                                                                            */
/*   QHLLAPI.H                                                                */
/*                                                                            */
/*   Definitions for the Quick3270 EHLLAPI specification                      */
/*                                                                            */
/*   EHLAPI32.DLL is the standard EHLLAPI interface                           */
/*   PCSHLL32.DLL is the extended EHLLAPI interface                           */
/*                                                                            */
/******************************************************************************/


/*----------------------------------------------------------------------------*/
/* EHLLAPI Function Numbers                                                   */
/*----------------------------------------------------------------------------*/

#define CONNECTPS               1       /* Connect Presentation Space         */
#define DISCONNECTPS            2       /* Disconnect Presentation Space      */
#define SENDKEY                 3       /* Send Key                           */
#define WAIT                    4       /* Wait                               */
#define COPYPS                  5       /* Copy Presentation Space            */
#define SEARCHPS                6       /* Search Presentation Space          */
#define QUERYCURSORLOC          7       /* Query Cursor Location              */
#define COPYPSTOSTR             8       /* Copy Presentation Space To String  */
#define SETSESSIONPARAMETERS    9       /* Set Session Parameters             */
#define QUERYSESSIONS           10      /* Query Sessions                     */
#define RESERVE                 11      /* Reserve                            */
#define RELEASE                 12      /* Release                            */
#define COPYOIA                 13      /* Copy OIA Information               */
#define QUERYFIELDATTRIBUTE     14      /* Query Field Attribute              */
#define COPYSTRTOPS             15      /* Copy String To Presentation Space  */
#define GETNLSINFORMATION       16      /* Get NLS Information Function       */
#define PAUSE                   18      /* Pause                              */
#define QUERYSYSTEM             20      /* Query System                       */
#define RESETSYSTEM             21      /* Reset System                       */
#define QUERYSESSIONSTATUS      22      /* Query Session Status               */
#define STARTHOSTNOTIFICATION   23      /* Start Host Notification            */
#define QUERYHOSTUPDATE         24      /* Query Host Update                  */
#define STOPHOSTNOTIFICATION    25      /* Stop Host Notification             */
#define SEARCHFIELD             30      /* Search Field                       */
#define FINDFIELDPOSITION       31      /* Find Field Position                */
#define FINDFIELDLENGTH         32      /* Find Field Length                  */
#define COPYSTRINGTOFIELD       33      /* Copy String To Field               */
#define COPYFIELDTOSTRING       34      /* Copy String To Field               */
#define SETCURSOR               40      /* Set Cursor                         */
#define STARTCLOSEINTERCEPT     41      /* Start Close Intercept              */
#define QUERYCLOSEINTERCEPT     42      /* Query Close Intercept              */
#define STOPCLOSEINTERCEPT      43      /* Stop Close Intercept               */
#define STARTKSINTERCEPT        50      /* Start Keystroke Intercept          */
#define GETKEY                  51      /* Get Key function                   */
#define POSTINTERCEPTSTATUS     52      /* Post Intercept                     */
#define STOPKSINTERCEPT         53      /* Stop Keystroke                     */
#define SENDFILE                90      /* Send File                          */
#define RECEIVEFILE             91      /* Receive File                       */
#define CONVERT                 99      /* Convert Position or RowCol         */

#define CONNECTWINDOWSERVICES    101    /* Connect to the Window Services     */
#define DISCONNECTWINDOWSERVICES 102    /* Disconnect from Window Services    */
#define QUERYWINDOWCOORDINATES   103    /* Query or Set Window Coordinates    */
#define WINDOWSTATUS             104    /* Query or Set Window Status         */
#define CHANGEPSNAME             105    /* Change Presentation Space Name     */
#define CHANGEWINDOWNAME         106    /* Change PS Window                   */



/*----------------------------------------------------------------------------*/
/* EHLLAPI Return Codes                                                       */
/*----------------------------------------------------------------------------*/

#define RC_SUCCESS               0	/* Good return code.                  */
#define RC_INVALID_PS            1	/* Invalid PS, Not connected.         */
#define RC_INVALID_PARAMETER     2	/* Bad parameter, or verb not         */
                                        /* supported.                         */
#define RC_FTXCOMPLETE           3	/* File Transfer Complete.            */
#define RC_BUSY                  4	/* PS is busy.                        */
#define RC_LOCKED                5	/* PS is locked, or invalid keystroke.*/
#define RC_TRUNCATION            6	/* Truncation occured, or invalid     */
                                        /* length.                            */
#define RC_INVALID_PS_POS        7	/* Invalid PS position.               */
#define RC_NO_PRIOR_START        8      /* No prior start keystroke int. or   */
                                        /* host notify return code.           */
#define RC_SYSTEM_ERROR          9      /* A system error occured.            */
#define RC_UNSUPPORTED           10     /* Invalid or unsupported function    */
                                        /* number.                            */
#define RC_UNAVAILABLE           11     /* Resource is unavalible at this     */
                                        /* time.                              */
#define RC_SESSION_STOPPED       12     /* Session has been stopped.          */
#define RC_BAD_MNEMONIC          20     /* Illegal mnemonic.                  */ 
#define RC_OIA_UPDATE            21     /* A OIA update occurred.             */
#define RC_PS_UPDATE             22     /* A PS update occurred.              */
#define RC_PS_AND_OIA_UPDATE     23     /* A PS and OIA update occurred.      */
#define RC_STR_NOT_FOUND_UNFM_PS 24     /* String not found, or Unformated PS.*/
#define RC_NO_KEYS_AVAIL         25     /* No keys available.                 */
#define RC_HOST_UPDATE           26     /* A HOST update occurred.            */
#define RC_FTXABORTED            27     /* File transfer aborted.             */
#define RC_FIELD_LEN_ZERO        28     /* Field length = 0.                  */
#define RC_QUEUE_OVERFLOW        31     /* Keystroke queue overflow.          */
#define RC_ANOTHER_CONNECTION    32     /* Successful. Another Structured     */
                                        /* Field connection to this           */
   
#define RC_FILENOTFOUND         302     /* File Not Found.                    */
#define RC_ACCESSDENIED         305     /* Access Denied.                     */
#define RC_MEMORY               308     /* Insufficient Memory.               */

#define RC_INVALIDHOST         9998     /* Invalid short name session ID or a */
                                        /* system error                       */
#define RC_NOTPANDNOTR         9999     /* Byte 2 in Data String on the call  */
                                        /* is invalid (neither "P" nor "R").  */


/*----------------------------------------------------------------------------*/
/* SetSessionParameters definitions                                           */
/*----------------------------------------------------------------------------*/

#define WHLL_SSP_NEWRET      (DWORD)0x00000001
#define WHLL_SSP_OLDRET      (DWORD)0x00000002
#define WHLL_SSP_ATTRB       (DWORD)0x00000004
#define WHLL_SSP_NOATTRB     (DWORD)0x00000008
#define WHLL_SSP_NWAIT       (DWORD)0x00000010
#define WHLL_SSP_LWAIT       (DWORD)0x00000020
#define WHLL_SSP_TWAIT       (DWORD)0x00000040
#define WHLL_SSP_EAB         (DWORD)0x00000080
#define WHLL_SSP_NOEAB       (DWORD)0x00000100
#define WHLL_SSP_AUTORESET   (DWORD)0x00000200
#define WHLL_SSP_NORESET     (DWORD)0x00000400
#define WHLL_SSP_SRCHALL     (DWORD)0x00001000
#define WHLL_SSP_SRCHFROM    (DWORD)0x00002000
#define WHLL_SSP_SRCHFRWD    (DWORD)0x00004000
#define WHLL_SSP_SRCHBKWD    (DWORD)0x00008000
#define WHLL_SSP_FPAUSE      (DWORD)0x00010000
#define WHLL_SSP_IPAUSE      (DWORD)0x00020000


/*---------------------------------------------------------------------------*/
/* Convert Row or Column flags                                               */
/*---------------------------------------------------------------------------*/

#define WHLL_CONVERT_POSITION 'P'
#define WHLL_CONVERT_ROW      'R'


/*----------------------------------------------------------------------------*/
/* Window Status values                                                       */
/*----------------------------------------------------------------------------*/

#define WHLL_WINDOWSTATUS_SET          0x01
#define WHLL_WINDOWSTATUS_QUERY        0x02
#define WHLL_WINDOWSTATUS_EXTQUERY     0x03

#define WHLL_WINDOWSTATUS_NULL         0x0000
#define WHLL_WINDOWSTATUS_SIZE         0x0001
#define WHLL_WINDOWSTATUS_MOVE         0x0002
#define WHLL_WINDOWSTATUS_ZORDER       0x0004
#define WHLL_WINDOWSTATUS_SHOW         0x0008
#define WHLL_WINDOWSTATUS_HIDE         0x0010
#define WHLL_WINDOWSTATUS_ACTIVATE     0x0080
#define WHLL_WINDOWSTATUS_DEACTIVATE   0x0100
#define WHLL_WINDOWSTATUS_MINIMIZE     0x0400
#define WHLL_WINDOWSTATUS_MAXIMIZE     0x0800
#define WHLL_WINDOWSTATUS_RESTORE      0x1000

#define WHLL_WINDOWSTATUS_FRONT        (DWORD)0x00000003
#define WHLL_WINDOWSTATUS_BACK         (DWORD)0x00000004


/*---------------------------------------------------------------------------*/
/* Change PS Name values                                                     */
/*---------------------------------------------------------------------------*/

#define WHLL_CHANGEPSNAME_SET          0x01
#define WHLL_CHANGEPSNAME_RESET        0x02


/*----------------------------------------------------------------------------*/
/* Api Function Prototypes                                                    */
/*----------------------------------------------------------------------------*/

extern long far pascal hllapi(WORD*, LPSTR, WORD*, WORD*);
extern HANDLE WINAPI WinHLLAPIAsync(HWND, LPWORD, LPSTR, LPWORD, LPWORD);
